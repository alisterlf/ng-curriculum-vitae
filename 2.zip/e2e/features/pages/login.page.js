/**
 * @file login.page.js
 */
var LoginPage = function() {
  const json = require('../locators/login.json');
  const helper = require('protractor-xp-helper');
  const { submitBt, emailInput, homeComponent, adfsScreen, passInput } = json.locators;
  const usernames = json.usernames;
  const { URL_HML } = json.constants;

  this.get = function() {
    browser.driver.get(URL_HML);
    helper.waitForElementPresence(adfsScreen);
  };

  this.doLogin = type => {
    this.fillUserName(type);
    this.fillPassword(type);
  };

  this.fillUserName = type => {
    var user = usernames[type];
    helper.fillFieldWithTextWhenVisible(emailInput, user.value);
  };

  this.fillPassword = type => {
    var user = usernames[type];
    helper.fillFieldWithTextWhenVisible(passInput, user.password);
    helper.clickWhenClickable(submitBt);
  };

  this.checkCurrentPage = () => {
    helper.waitForElementPresence(homeComponent);
  };
};

module.exports = new LoginPage();
