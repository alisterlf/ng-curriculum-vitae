//Login Step Definitions File
const { After } = require('cucumber');

After(async function() {
  const world = this;
  await browser.driver.takeScreenshot().then(function(buffer) {
    return world.attach(buffer, 'image/png');
  });
});
