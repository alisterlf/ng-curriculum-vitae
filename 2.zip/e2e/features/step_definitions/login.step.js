//Login Step Definitions File
const { Given, When, Then } = require('cucumber');
const LoginPage = require('./../pages/login.page');
const globalTimeout = 20 * 1000;

Given('que estou na tela de login', { timeout: globalTimeout }, callback => {
  LoginPage.get();
  browser.driver.sleep(1).then(callback);
});

When('um usuário {string} é preenchido', { timeout: globalTimeout }, (field, callback) => {
  LoginPage.fillUserName(field);
  browser.driver.sleep(1).then(callback);
});

When('um password {string} é preenchido', { timeout: globalTimeout }, (field, callback) => {
  LoginPage.fillPassword(field);
  browser.driver.sleep(1).then(callback);
});

Then('a home logada deve ser apresentada', { timeout: globalTimeout }, (string, callback) => {
  LoginPage.checkCurrentPage(string);
  browser.driver.sleep(1).then(callback);
});
