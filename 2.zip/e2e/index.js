var reporter = require('cucumber-html-reporter');

var options = {
  theme: 'foundation',
  jsonFile: 'e2e/results/output_result.json',
  output: 'e2e/results/html/cucumber_report.html',
  launchReport: true,
  name: 'Testing New Report',
  storeScreenshots: true,
  screenshotsDirectory: 'e2e/results/html/screenshots/',
  metadata: {
    'App Version': '0.3.2',
    'Test Environment': 'HML',
    Browser: 'Chrome',
    Platform: 'Windows 10',
    Parallel: 'Scenarios',
    Executed: 'Remote'
  }
};

reporter.generate(options);
