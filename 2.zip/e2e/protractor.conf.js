exports.config = {
  getPageTimeout: 60000,
  allScriptsTimeout: 500000,
  specs: ['features/*.feature'],
  capabilities: {
    browserName: 'chrome'
  },
  ignoreUncaughtExceptions: true,
  directConnect: true,
  baseUrl: 'http://localhost:4200/',
  framework: 'custom',
  frameworkPath: require.resolve('protractor-cucumber-framework'),
  cucumberOpts: {
    require: [
      'features/step_definitions/*.step.js',
      'features/step_definitions/commonSteps/*.step.js'
    ],
    profile: false,
    tags: [],
    'no-source': true,
    format: 'json:e2e/results/output_result.json'
  },
  onPrepare() {
    browser
      .manage()
      .window()
      .maximize();
    browser.waitForAngularEnabled(false);
  }
};
