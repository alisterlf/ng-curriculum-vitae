// angular-cli proxy config
// https://github.com/angular/angular-cli/blob/master/docs/documentation/stories/proxy.md

// to solve CORS problems you have to send a request to localhost:4200/something
// the proxy will itercept requests sent to /something and redirect to the correct address
// the proxy will also set a request origin and Access-Control-Allow-Origin

const services = {
  '/apiBaseUrl': 'http://api.dsv.xpi.com.br:8080'
};

function buildConfig(services) {
  const PROXY_CONFIG = {};

  for (path in services) {
    let config = {};
    let pathRewrite = {};

    config.target = services[path];
    config.secure = false;

    pathRewrite[`^${path}`] = '';
    config.pathRewrite = pathRewrite;

    PROXY_CONFIG[path] = config;
  }

  return PROXY_CONFIG;
}

module.exports = buildConfig(services);
