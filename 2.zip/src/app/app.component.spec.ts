import { APP_BASE_HREF } from '@angular/common';
import { TestBed } from '@angular/core/testing';
import { IAdfsConfig, XpAdfsModule } from '@xp-backoffice/xp-core-toolkit/adfs';
import { AppComponent } from './app.component';
import { AppModule } from './app.module';

const adfs: IAdfsConfig = {
  clientId: '',
  autoLogin: false,
  disableAdfs: true
};

describe('AppComponent', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [AppModule, XpAdfsModule.forRoot(adfs)],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }]
    });
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

  it('should render frame title "Fundos de investimento - Backoffice"', () => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('xp-frame').textContent).toContain(
      'Fundos de investimento - Backoffice'
    );
  });
});
