import { Component } from '@angular/core';
import { IMenu } from '@xp-backoffice/xp-core-toolkit/sidemenu';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  menu: IMenu[] = [
    {
      label: 'Home',
      routerLink: 'home',
      icon: 'home'
    },
    {
      label: 'Ordens',
      routerLink: 'orders',
      icon: 'description'
    }
  ];
}
