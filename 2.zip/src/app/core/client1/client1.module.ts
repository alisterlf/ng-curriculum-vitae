import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { environment } from '@env/environment';
import { Client1EndpointService, CLIENT1_BASE_URL } from './client1';

@NgModule({
  imports: [CommonModule],
  declarations: [],
  providers: [
    {
      provide: CLIENT1_BASE_URL,
      useValue: environment.services.apiBaseUrl
    },
    Client1EndpointService // import your genereted services here!
  ],
  exports: []
})
export class Client1Module {}
