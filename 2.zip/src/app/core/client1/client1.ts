// Client1 services will be automatically generated here

export const CLIENT1_BASE_URL = '';

export class Client1EndpointService {
  constructor() {}
}
