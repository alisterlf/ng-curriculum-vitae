import { CommonModule } from '@angular/common';
import { APP_INITIALIZER, NgModule } from '@angular/core';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { MAT_DATE_LOCALE } from '@angular/material/core';
import * as moment from 'moment';

export function initializeMomentJs() {
  return () =>
    new Promise(function(resolve) {
      moment.locale('pt-br');
      resolve();
    });
}

@NgModule({
  imports: [CommonModule, MatMomentDateModule],
  declarations: [],
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: initializeMomentJs,
      multi: true
    },
    { provide: MAT_DATE_LOCALE, useValue: 'pt-br' }
  ]
})
export class MomentIntegrationModule {}
