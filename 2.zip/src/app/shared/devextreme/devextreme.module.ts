import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import {
  DxCheckBoxModule,
  DxDataGridModule,
  DxSelectBoxModule
} from 'devextreme-angular';

@NgModule({
  imports: [
    CommonModule,
    DxDataGridModule,
    DxSelectBoxModule,
    DxCheckBoxModule
  ],
  declarations: [],
  exports: [DxDataGridModule, DxSelectBoxModule, DxCheckBoxModule]
})
export class DevextremeModule {}
