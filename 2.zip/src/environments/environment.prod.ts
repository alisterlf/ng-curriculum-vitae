export const environment = {
  production: true,
  services: {
    apiBaseUrl: '#{{API_URL}}#:8080' // Ver /proxy.conf.js
  },
  adfs: {
    instance: 'https://fs.xpi.com.br/', // 1
    tenant: 'adfs', // 1
    clientId: '#{{ADFS_CLIENT_ID}}#', // 2, 3
    autoLogin: true,
    cacheLocation: 'localStorage'
  }
};

// 1 - Valores nunca mudam
// 2 - Solicitar clientId da aplicação pelo Taylor buscando po "Criação de aplicação no ADFS"
// 3 - Configurar clientId por variável de ambiente no VSTS em:
//     "Build and release" ->
//     "Releases" ->
//     *Buscar seu projeto e clicar em Edit* ->
//     "Variables"
