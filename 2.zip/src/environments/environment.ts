import { IAdfsConfig } from '@xp-backoffice/xp-core-toolkit/adfs/adal';
// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  services: {
    apiBaseUrl: 'https://sak-front-dsv.xpi.com.br:8080' // Ver /proxy.conf.js
  },
  adfs: <IAdfsConfig>{
    instance: 'https://fs.xpi.com.br/', // 1
    tenant: 'adfs', // 1
    clientId: '16e95455-90b2-4902-a6a5-e16cd6096d85', //  2, 3
    autoLogin: true,
    cacheLocation: 'localStorage'
  }
};

// 1 - Valores nunca mudam
// 2 - Solicitar clientId da aplicação pelo Taylor buscando po "Criação de aplicação no ADFS"
// 3 - Configurar clientId por variável de ambiente no VSTS em:
//     "Build and release" ->
//     "Releases" ->
//     *Buscar seu projeto e clicar em Edit* ->
//     "Variables"
